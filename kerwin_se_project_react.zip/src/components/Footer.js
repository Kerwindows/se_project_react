import React from "react";

function Footer() {
  return (
    <>
      <footer className='footer'>
        <p className='footer__copyright'>© 2022 Around React</p>
      </footer>
    </>
  );
}

export default Footer;
